# 导入需要的包
from flask import Flask

# 初始化Flask
app = Flask(__name__)


# 注意,这个注解是核心("/"是主路线)
@app.route("/")
# 创建一个返回"hello world！！!"
def index():
    return "hello world！！!"


# 第一种方法
# 只有Get方法才能访问
@app.route("/h", methods=["GET"])
def get():
    return "你用的是Get哟"


# 只有Get方法才能访问
@app.route("/h", methods=["POST"])
def post():
    return "你用的是Post哟"


# 第二种方法
# 首先导入request包
from flask import request


@app.route("/n", methods=["GET", "POST"])
def getAndPost():
    method = request.method
    # 判断访问是get还是post
    if method == "GET":
        return "你用的是%s哟" % method
    elif method == "POST":
        return "你用的是%s哟" % method


# 添加参数
# 第一种方法 注意(访问一定要加"/add/参数"形式;例如/add/张三,不然会404)
@app.route("/add/<username>")
def addUsername(username):
    return "参数传过来了，你是%s" % username


# 如果要指定传过来的参数是整形的话,如下;
@app.route("/add/<int:age>")
def addAge(age):
    return "参数传过来了，你现在%d岁" % age


# 第二种
@app.route("/add")
def add():
    name = request.args.get("username")
    age = request.args.get("age")
    return "参数传过来了，你是%s，目前%s岁！" % (name, age)

# 模板渲染
#首先导包
from flask import render_template

# 简单
@app.route("/index")
def html():
    return render_template("/index.html")

#基础
@app.route("/test/<username>")
def test(username):
    return render_template("/test.html",username=username)

# 进阶(一)
@app.route("/list")
def h_list():
    list = ["张三","李四","王五"]
    return render_template("/list.html",list=list)

# 进阶二
@app.route("/list2")
def h_list2():
    list = ["张三","李四","王五"]
    return render_template("/list2.html",list=list)

# main方法
if __name__ == '__main__':
    # 运行方法(port:(int)端口,debug:Boolean)是否开始界面报错通知)
    app.run(port=80, debug=True)
