from flask import Flask

app = Flask(__name__)


@app.route("/1")
def method1():
    # 最基本的
    dict = {"code": 200, "msg": "success", "data": [{"name": "张三", "age": "32"}, {"name": "李四", "age": "36"}]}
    return dict


# 首先得导转换包jsonify
from flask import jsonify


@app.route("/2")
def method2():
    # 基本的json列表，不过还是需要转,因为默认只能返回string,tuple,dict
    dict1 = {"name": "张三", "age": "32"}
    dict2 = {"name": "李四", "age": "36"}
    list = [dict1, dict2]
    return jsonify(list)


@app.route("/3")
def method3():
    # 这列表的长度一定得保证一样
    lists_name = ["张三", "李四"]
    lists_age = [32, 36]
    list_l = []
    # 循环(0,列表长度)
    for i in range(0,len(lists_name)):
        dict = {}
        # 这里自定义字段,我举了name和age
        dict["name"] = lists_name[i]
        dict["age"] = lists_age[i]
        list_l.append(dict)
    return jsonify(list_l)


if __name__ == '__main__':
    app.run(debug=True)
