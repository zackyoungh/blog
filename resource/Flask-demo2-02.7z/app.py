from flask import Flask
from flask_script import Manager, Server

app = Flask(__name__)

# 导入刚刚加的字段user
from blueprint import user

# 蓝本注册
# url_prefix是指定路由前缀，而且优先级比创建时的高，必须以/斜杠开头
# 也可以不加
# app.register_blueprint(user)
app.register_blueprint(user, url_prefix="/user")

# 初始化manage
manage = Manager(app)

# 添加一个runserver参数运行环境
manage.add_command("runserver",Server(use_debugger=True,port=5000,host="127.0.0.1"))

if __name__ == '__main__':
    manage.run()
