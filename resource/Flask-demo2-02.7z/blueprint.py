from flask import Blueprint

# 对象
user = Blueprint("user", __name__)


# 视图函数
@user.route("/")
def index():
    return "hello!!"
