from flask import Flask
from app.config import config
from app.extensions import config_extensions
from app.views import config_blueprint


def create_app(config_name):
    app = Flask(__name__)
    # config.get()等同于config['']
    app.config.from_object(config.get(config_name) or config['default'])
    config_extensions(app)
    config_blueprint(app)
    config_errorhandler(app)
    return app


# 修改报错通知页面
def config_errorhandler(app):
    # 404界面
    @app.errorhandler(404)
    def page_not_found(e):
        return "这里是404界面！"
