from app.extensions import db

from .product import Product
