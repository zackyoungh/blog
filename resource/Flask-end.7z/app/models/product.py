from app.extensions import db


class Product(db.Model):
    # 表名
    __tablename__ = "product"
    # id，primary_key是否是主键,名字和类型必须和数据对应
    id = db.Column(db.Integer, primary_key=True)
    # varchar类型对应String
    name = db.Column(db.String(255))
    price = db.Column(db.Integer)
    description = db.Column(db.String(255))

    # 实体类添加to_dict解析成字典模式
    def to_dict(self):
        return {c.name: getattr(self, c.name, None)
                for c in self.__table__.columns}
