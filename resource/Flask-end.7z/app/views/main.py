from flask import Blueprint,render_template
from app.models import Product,db

main = Blueprint("main", __name__)


# 第二种
@main.route("/product")
def user_index():
    # sqlalchemy语法
    product = Product.query.all()
    return render_template("/index.html", product=product)


# 第一种
@main.route("/")
def index():
    product = db.session.execute('select * from product').fetchall()
    return render_template("/index.html", product=product)
