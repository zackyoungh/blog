from flask_script import Manager, Server
from flask_migrate import MigrateCommand
from app import create_app
import os

# 系统检测环境配置,如果没有就会选择默认环境
config_name = os.environ.get("FLASK_CONFIG") or "default"
# 创建app,此刻app初始化单独分出来，因为后面需要配置的文件有些多
app = create_app(config_name)
manage = Manager(app)

# 添加运行参数命令
manage.add_command("runserver", Server(port=80, use_debugger=True))
# 这是数据库迁移操作，具体用法百度
manage.add_command("db", MigrateCommand)

if __name__ == '__main__':
    manage.run()
