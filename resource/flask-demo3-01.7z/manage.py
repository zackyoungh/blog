from flask import Flask, jsonify
from flask_script import Manager, Server
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# # 第一种方法直接使用字典字典赋值
# # 这是配置连接源 (mysql+pymysql)这是连接方式，注意顺序不能颠倒,
# # root:password@localhost:3306/test
# # 数据库账号:密码@连接IP地址/数据库名
# app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+pymysql://root:1052455797@localhost:3306/test"
# # 如果设置成 True (默认情况)，Flask-SQLAlchemy 将会追踪对象的修改并且发送信号。这需要额外的内存， 如果不必要的可以禁用它。
# app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = True


# # 第二种连接方法
# class DevelopmentConfig:
#     SQLALCHEMY_TRACK_MODIFICATIONS = False
#     SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:1052455797@localhost:3306/test'
# app.config.from_object(DevelopmentConfig)


# 第三种连接方法（使用配置文件）
app.config.from_pyfile("config.ini")

# 初始化数据库
db = SQLAlchemy()
db.init_app(app)
manage = Manager(app)


@app.route("/")
def index():
    try:
        results = db.session.execute("SELECT VERSION()").fetchone()
        if (results[0] is None):
            return "null"
        else:
            return "数据库连接成功,当前数据库版本为%s" % results[0]

    except:
        return "数据库连接失败,请检查格式或账号密码"


manage.add_command("runserver", Server(port=5000, use_debugger=True))
if __name__ == '__main__':
    manage.run()
