from flask import Flask, jsonify
from flask_script import Manager, Server
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+pymysql://root:1052455797@localhost:3306/test"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = True

db = SQLAlchemy()
db.init_app(app)
manage = Manager(app)


class User(db.Model):
    # 表名
    __tablename__ = "user"
    # id，primary_key是否是主键,名字和类型必须和数据对应
    id = db.Column(db.Integer, primary_key=True)
    # varchar类型对应String
    username = db.Column(db.String(255))

    # 实体类添加to_dict解析成字典模式
    def to_dict(self):
        return {c.name: getattr(self, c.name, None)
                for c in self.__table__.columns}


# 第二种
@app.route("/user")
def user_index():
    # sqlalchemy语法
    user = User.query.all()
    list = [v.to_dict() for v in user]
    return jsonify(list)


# 第一种
@app.route("/")
def index():
    # 表里面数据是这样的
    # --id----username--
    # --1----张三--
    # 对应的 user查询结果是[(1,"张三")]；fetchall函数是返回全部row,fetchone返回一个row,limit是条数限制
    user = db.session.execute('select * from user').fetchall()
    # 返回的结果是对应数据库字段的json格式
    return jsonify([dict(zip(item.keys(), item)) for item in user])


manage.add_command("runserver", Server(port=5000, use_debugger=True))
if __name__ == '__main__':
    manage.run()
